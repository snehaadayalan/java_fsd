package selenium;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

public class web_elements {
	public static void main(String[] args) {
	      System.setProperty("webdriver.chrome.driver",    
	    		  "D:\\chromedriver_win32\\chromedriver_win32\\chromedriver.exe");
	   
	      WebDriver driver = new ChromeDriver();
	      String url = "https://www.tutorialspoint.com/index.htm";
	      driver.get(url);
	      driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
	      driver.findElement(By.className("gsc-input"))
	      .sendKeys("Selenium");
	      driver.close();
	   }
	}