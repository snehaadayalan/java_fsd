package com.example.test;

public class PersonResonse {

	public void setPersonId(Integer personId) {
		// TODO Auto-generated method stub
		
	}

}
