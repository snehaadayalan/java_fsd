import { SearchTodoPipe } from './search-todo.pipe';

describe('SearchTodoPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchTodoPipe();
    expect(pipe).toBeTruthy();
  });
});
