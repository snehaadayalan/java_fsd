package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Feedback {
@Id
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fid;
	public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPstar() {
	return pstar;
}
public void setPstar(int pstar) {
	this.pstar = pstar;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getSstar() {
	return sstar;
}
public void setSstar(int sstar) {
	this.sstar = sstar;
}
	private String pname;
	private int pstar;
	private String sname;
	private int sstar;
	private String comment;
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

}
