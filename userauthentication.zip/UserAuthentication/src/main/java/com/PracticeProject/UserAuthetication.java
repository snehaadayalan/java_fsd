package com.PracticeProject;

public class UserAuthetication {
      public  String getUserName() {
    	  return "sneha";
      }
      public  String getEmail() {
    	  return "snehadayalan19@gmail.com";
      }
      public  int getPhoneNum() {
    	  return 1234567890 ;
      }
      public  String getPassword() {
    	  return "Sneha@19";
      }
}
