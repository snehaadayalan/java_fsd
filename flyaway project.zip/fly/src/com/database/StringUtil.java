package com.database;

public class StringUtil {

	public static String fixSqlFieldValue(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
