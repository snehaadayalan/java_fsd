package com.ecommerce.entity;

public class List<T> {

}
