package com.ecommerce.entity;

import java.util.List;

public class model {

	public static void addAttribute(String string, com.ecommerce.entity.List<EProductEntity> list) {
		// TODO Auto-generated method stub
		
	}

}
