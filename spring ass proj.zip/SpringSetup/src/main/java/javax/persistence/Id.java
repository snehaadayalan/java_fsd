package javax.persistence;

public class Id {

}
