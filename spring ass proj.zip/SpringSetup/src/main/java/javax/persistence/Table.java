package javax.persistence;

public class Table {

}
