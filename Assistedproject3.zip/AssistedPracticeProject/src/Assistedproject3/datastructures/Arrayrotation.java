package Assistedproject3.datastructures;

class RotateArray { 
public void rotate(int[] nums, int d) {
    		if(d > nums.length) 
       			d=d%nums.length;
 		int[] result = new int[nums.length];
 		for(int i=0; i < d; i++){
        			result[i] = nums[nums.length-d+i];
 		}
 		int j=0;
    		for(int i=d; i<nums.length; i++){
    			result[i] = nums[j];
    			j++;
    			    		}
    			 		System.arraycopy( result, 0, nums, 0, nums.length );
    			}
    			} 
    			public class Arrayrotation
    			{
    				public static void main(String[] args) {
    					RotateArray r = new RotateArray();
    			        		int arr[] = {4,3,5,6,7,8,9,1 }; 
    			        		r.rotate(arr, 5); 
    			        		for(int i=0;i<arr.length;i++){
    			            			System.out.print(arr[i]+" ");
    			        		}
    				}
    			}


	
