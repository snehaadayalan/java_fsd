package practiceproj;
import java.util.regex.*;    
import java.util.*;    
public class emailid {

	    
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	//Storing list of emailid in an array
	 String Array[]= {"sakthid099@gmail.com@gmail.com",
			          "snehadayalan19@gmail.com",
			          "snehaa@gmail.com",
			           "sakthi@gmail.com",
			           "pranav@gmail.com",
			           "vani@gmail.com",
			           "dayalan@96@gmail.como",
			           "vanidaya@gmail.com",
			           "ssss@gmail.com",
			           "dvsp@gmail.com"};
			
	 System.out.println("Enter the EmailId to search");
	//Get input from user to search emailid
   String s=sc.next();
   //Validating email
      
      for(int  i=0;i<Array.length;i++)
       {
    	  
       if(Array[i].equals(s))
       {
       
    	   System.out.println("EmailId validated");
       
       }
      else {
    	  System.out.println("Invalid email");
      }
       }
    
       
       
       
       

	 
	        
	        

       
       }


}