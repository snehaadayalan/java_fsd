package web_app;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterAutomation {
	public static void main(String args[]) throws InterruptedException {
		
	    System.setProperty("webdriver.chrome.driver", 
	    		  "D:\\chromedriver_win32\\chromedriver.exe");

	    		WebDriver driver = new ChromeDriver(); 
	    	    driver.get("file:///C:/Users/Sneha/java/phase_5/src/web_app/register.html");
	    
	    driver.manage().window().maximize();
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("name")).sendKeys("Sneha D");
	    Thread.sleep(5000);
	    driver.findElement(By.name("mail")).sendKeys("sneha@email.com");
	    Thread.sleep(5000);
	    driver.findElement(By.id("pass1")).sendKeys("sneha123");
	    Thread.sleep(5000);
	    driver.findElement(By.id("pass2")).sendKeys("sneha123");
	    Thread.sleep(5000);
	        
	    Select g = new Select(driver.findElement(By.id("gen")));
	    Thread.sleep(5000);
	    g.selectByValue("female");
	    driver.findElement(By.name("add")).sendKeys("Tamilnadu");
	    Thread.sleep(5000);
	    driver.findElement(By.name("phone")).sendKeys("0000011111");
	    Thread.sleep(5000);
	        
	    String pagetit= driver.getTitle();
		System.out.println("Register Driver title = "+ pagetit);
		String actualtit = "Registration";
		
		if(actualtit.equalsIgnoreCase(pagetit))
		{
			System.out.println("Registration Tested Successfully!");
		}
		else
		{
			System.out.println("Register Test is not Successfull");
		}
		
		 driver.findElement(By.xpath("//button[contains(text(),'Register')]")).click();
		 Thread.sleep(5000);
		 driver.close();        
	}
}