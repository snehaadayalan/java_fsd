package Assistedproject4;

public class insertionsort {

    public static  void main(String[] args){

        int[] arr = {9,19,29,39,49};
        insertionsort(arr);
        for(int i=0;i<arr.length;i++){

            System.out.println(arr[i]);

        }
     }
    public static void insertionsort(int[] arr){

    	int len = arr.length;
        for(int j=1;j<len;j++){
        int key = arr[j];
        int i=j-1;
        while ((i>-1) && (arr[i]>key)){

            arr[i+1]=arr[i];
            i--;
        }
        arr[i+1]=key;
             }

        }
    }
