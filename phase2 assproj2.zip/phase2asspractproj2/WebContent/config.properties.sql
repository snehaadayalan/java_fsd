url=jdbc:mysql://localhost:3306/ecommerce
userid=root
password=root
