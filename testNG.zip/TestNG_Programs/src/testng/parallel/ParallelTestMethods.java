package testng.parallel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ParallelTestMethods {
    
	    @Test    
        public void executSessionOne(){
            //First session of WebDriver
	    	System.setProperty("webdriver.chrome.driver",
		    		  "D:\\chromedriver_win32\\chromedriver.exe");

	    			ChromeDriver driver = new ChromeDriver();	
            
            driver.get("http://demo.guru99.com/V4/");
            //find user name text box and fill it
            driver.findElement(By.name("uid")).sendKeys("Driver 1");        
        }
        
        @Test    
        public void executeSessionTwo() {
    	
        //Second session of WebDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Virendra\\Desktop\\Simplilearn\\All Phases\\Phase-5\\Selenium Material\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();	
            
        driver.get("http://demo.guru99.com/V4/");
        //find user name text box and fill it
        driver.findElement(By.name("uid")).sendKeys("Driver 2");
        
        }
        
        @Test    
        public void executSessionThree(){
    	
        //Third session of WebDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Virendra\\Desktop\\Simplilearn\\All Phases\\Phase-5\\Selenium Material\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();	
          
        driver.get("http://demo.guru99.com/V4/");
        //find user name text box and fill it
        driver.findElement(By.name("uid")).sendKeys("Driver 3");      
        }        
}
