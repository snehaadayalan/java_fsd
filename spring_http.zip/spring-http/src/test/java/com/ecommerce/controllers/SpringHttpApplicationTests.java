/*package com.ecommerce.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHttpApplicationTests {

	@Test
	void contextLoads() {
	}

}*/
