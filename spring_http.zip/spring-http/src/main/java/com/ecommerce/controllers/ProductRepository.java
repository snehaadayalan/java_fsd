package com.ecommerce.controllers;

public class ProductRepository {

}
