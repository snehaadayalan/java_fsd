package com.ecommerce.controllers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHttpApplication.class, args);
	}

}
