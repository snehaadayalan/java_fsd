package Assistedproject;

public class methodexec {

	
		// TODO Auto-generated constructor stub
		public int multipynumbers(int a,int b) {
			int z=a*b;
			return z;
		}

		public static void main(String[] args) {
			methodexec b=new methodexec();
			int ans= b.multipynumbers(100,100);
			System.out.println("Multipilcation is :"+ans);
			}

	}


