package Assistedproject;

public class StringBufferProgram {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Heelloo "); 
		
		sb.append("hai");         
		System.out.println(sb);   
		
		sb.insert(1,"hai");     
		System.out.println(sb);  
		
		sb.replace(1,3,"hai");  
		System.out.println(sb);
		
		sb.delete(1,3);  
		System.out.println(sb);
		
		sb.reverse();  
		System.out.println(sb);
		
		System.out.println(sb.charAt(3));
		
		StringBuilder ss = new StringBuilder("Code");
		
		System.out.println(">>>>>>>"+ ss);
		ss.append("hai");
		System.out.println(">>>>>>>"+ ss);
		System.out.println(ss.length());
		System.out.println(ss.charAt(6));
		System.out.println(ss.reverse());
		
		
		}  
	}  

