package Assistedproject;


public class methodcalling {


		// TODO Auto-generated constructor stub
	int val=150;

	int operation(int val) {
		val =val*20/200;
		return(val);
	}

	public static void main(String args[]) {
		methodcalling d = new methodcalling();
		System.out.println("Before operation "+d.val);
		d.operation(100);
		System.out.println("After operation is "+d.val);
		}
	}
