package Assistedproject;
import java.util.*; 
import java.util.stream.*; 
import java.util.stream.Collectors;  
 class maps {

	 

	 	public static void main(String[] args) {
	 		// map
	 		
	 		//Hashmap
	 		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	 	      hm.put(1,"X");    
	 	      hm.put(2,"Y");    
	 	      hm.put(3,"Z");   
	 	     System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"A");  
		      ht.put(5,"B");  
		      ht.put(6,"C");  
		      ht.put(7,"D");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"M");    
		      map.put(9,"N");    
		      map.put(10,"P");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
}
 }