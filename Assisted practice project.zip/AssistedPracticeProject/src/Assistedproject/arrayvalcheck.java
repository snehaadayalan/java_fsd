package Assistedproject;

import java.util.Arrays;

public class arrayvalcheck {
		// TODO Auto-generated constructor stub
		private static void check(int[] arr, int toCheckValue)
	    {
	       
	        boolean test = false;
	        for (int element : arr) {
	            if (element == toCheckValue) {
	                test = true;
	                break;
	            }
	        }
	 
	       
	        System.out.println("Is " + toCheckValue
	                           + " present in the array: " + test);
	    }
	 
	    public static void main(String[] args)
	    {
	 
	     
	        int arr[] = { 1,2,3,4,5,6,6,7,8 };

	        int toCheckValue = 9;
	 
	        System.out.println("Array: "
	                           + Arrays.toString(arr));
	 
	 
	        check(arr, toCheckValue);
	    }
	
	}

