package Assistedproject;

class defAccessSpecifier
		// TODO Auto-generated constructor stub
		{ 
			  void display() 
			     { 
			         System.out.println("You are using defalut access specifier"); 
			     } 
			} 

		public class Accessmodifiers {

			public static void main(String[] args) {
				//default
				System.out.println("Dafault Access Specifier");
				Accessmodifiers obj = new Accessmodifiers(); 		  
		        
			}
		}


	


