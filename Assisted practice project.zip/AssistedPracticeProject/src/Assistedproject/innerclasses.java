package Assistedproject;
import java.lang.reflect.Modifier;


public class innerclasses {


   
    public static void main(String[] args)
    {
 
    
    	innerclasses gfg = new innerclasses();
 
     
        InnerClass innerClass = gfg.new InnerClass();
 
    
        StaticNestedClass statNested
            = new StaticNestedClass();
 
        
        Class classInstance1 = innerClass.getClass();
        Class classInstance2 = statNested.getClass();
 
      
 
        boolean isNested1
            = classInstance1.getEnclosingClass() != null;
       
        boolean isNested2
            = classInstance2.getEnclosingClass() != null;
 
        boolean isStatic1 = Modifier.isStatic(
            classInstance1.getModifiers());
        boolean isStatic2 = Modifier.isStatic(
            classInstance2.getModifiers());
 

        System.out.println(
            "Is innerClass an inner class object? : "
            + (isNested1 && !isStatic1));
 
        System.out.println(
            "Is staticNested an inner class object? : "
            + (isNested2 && !isStatic2));
    }
 
    // Inner Class
    class InnerClass {
    }
 
    // Static nested class
    static class StaticNestedClass {
    }
}