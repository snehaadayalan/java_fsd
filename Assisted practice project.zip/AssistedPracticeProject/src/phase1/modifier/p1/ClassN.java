package phase1.modifier.p1;

public class ClassN {

	double r=56.55;
	protected long v=4444444;
		
	public int work=134;
		
	public void printN(){
		System.out.println(r+" "+work+" "+v);
	}



		}
	



