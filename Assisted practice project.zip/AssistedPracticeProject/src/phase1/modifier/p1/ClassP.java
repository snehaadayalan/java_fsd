package phase1.modifier.p1;

	import phase1.modifier.p1.ClassM;
	import phase1.modifier.p1.ClassN;
	public class ClassP {

		public static void main(String[] args) {


	ClassN obj=new ClassN();
	ClassM obje=new ClassM();
	System.out.println("Variables of Class N are:"+obj.work);
	System.out.println("Variables of Class M are:"+obje.h);

		}

	}


