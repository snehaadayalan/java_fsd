package phase1.modifier.p1;

public class ClassM {
	
		
	private int type=40;
	long h=65789000;
	protected float re=7678.09f;
	public void print(){
		System.out.println(type+" "+h+" "+re);
	}
	}
	


