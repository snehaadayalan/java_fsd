package phase1.modifier.p2;

public class ClassX {

	private int q=33;
	long i=8798674;
	protected float j=785.667f;
	public char h='O';
	public void printX(){
		System.out.println(q+" "+i+" "+j+" "+h);
	}
	}